<?php
session_start();
include '../config/conexao.php';


// Verifica se o usuário está logado
if (!isset($_SESSION['usuario_id'])) {
  header('Location: ../login.php');
  exit;
}


// Obtém os pedidos do usuário logado
$usuario_id = $_SESSION['usuario_id'];
$sql = "SELECT * FROM pedidos WHERE usuario_id = ? ORDER BY created_at DESC";
$stmt = $conn->prepare($sql);
$stmt->bind_param("i", $usuario_id);
$stmt->execute();
$result = $stmt->get_result();
?>


<!DOCTYPE html>
<html lang="pt-BR">


<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <meta http-equiv="X-UA-Compatible" content="IE=edge">
  <title>Minhas Compras - Fast Food</title>
  <link rel="stylesheet" href="../css/index.css">


</head>


<body>
  <?php include '../includes/header.php'; ?>
  <div class="container">
    <h1>Minhas Compras</h1>


    <?php if ($result->num_rows > 0): ?>
      <div class="lista-compras">
        <?php while ($pedido = $result->fetch_assoc()): ?>
          <div class="compra-item">
            <div class="compra-info">
              <h3>Pedido #<?= $pedido['id']; ?></h3>
              <p><strong>Data do Pedido:</strong> <?= date('d/m/Y H:i', strtotime($pedido['created_at'])); ?></p>
              <p><strong>Total:</strong> R$ <?= number_format($pedido['total'], 2, ',', '.'); ?></p>
              <p><strong>Status:</strong> <?= ucfirst($pedido['status']); ?></p>
            </div>
            <div class="compra-detalhes">
              <a href="detalhes-pedido.php?id=<?= $pedido['id']; ?>" class="btn-detalhes">Ver Detalhes</a>
            </div>
          </div>
        <?php endwhile; ?>
      </div>
    <?php else: ?>
      <p>Você ainda não fez nenhuma compra.</p>
    <?php endif; ?>
  </div>


  <?php include '../includes/footer.php'; ?>


</body>


</html>

<footer>
  <div class="content">
  <div class="contato">
    <h1 class="title-contato">Contato</h1>
    <p><i class="fa-solid fa-phone" style="color: #000000;"></i>(16) 3203-8922</p>
    <p><i class="fa-solid fa-envelope" style="color: #000000;"></i>senhor.burguer@gmail.com</p>
  </div>

  <div class="redes">
    <h1>Redes sociais</h1>
    <a href=""><i class="fa-brands fa-whatsapp" style="color: #000000;"></i></a>
    <a href=""><i class="fa-brands fa-facebook" style="color: #000000;"></i></a>
    <a href=""><i class="fa-brands fa-instagram" style="color: #000000;"></i></a>
  </div>

  <div class="links">
    <h1>Links úteis</h1>
    <a href="../usuario/index.php">Home</a>
    <a href="../usuario/Sobre.php">Sobre</a>
    <a href="../usuario/carrinho.php">Carrinho</a>
    <a href="../perfil.php">Perfil</a>
  </div>
  </div>
  
  <div class="copyright">
    <hr>
    <br>
    <p>©Todos os direitos reservados | Desenvolvido por Kauã Lima, Eduardo Junqueira, julia delamonica e Beatriz marino</p>
  </div>
</footer>
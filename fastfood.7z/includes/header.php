<?php
// Verifica se a sessão já foi iniciada
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}
?>

<header class="start">
    <div class="img">
        <img src="../imgs/Logo.png" alt="">
    </div>
    <nav>
        <a href="/index.php"><i class="fa-solid fa-house" style="color: #f9b125;"></i></a>
        <a href="../usuario/Sobre.php"><i class="fa-sharp fa-solid fa-circle-exclamation" style="color: #f9b125;"></i></a>

        <?php if (isset($_SESSION['role'])) : ?>
            <?php if ($_SESSION['role'] === 'admin') : ?>
                <a href="/admin/vendas.php">Gerenciar Pedidos</a>
                <a href="/admin/adicionar_produto.php">Adicionar Produto</a>
            <?php elseif ($_SESSION['role'] === 'cliente') : ?>
                <a href="/usuario/compras.php"><i class="fas fa-cart-circle-check" style="line-height: 1; color: #F9B125;"></i></a>
                <a href="/usuario/carrinho.php"><i class="fa-solid fa-cart-shopping" style="color: #f9b125;"></i></a>
            <?php endif; ?>
            <a href="/logout.php"><i class="fa-solid fa-right-from-bracket" style="color: #f9b125;"></i></a>
        <?php else: ?>
            <a href="/carrinho.php"><i class="fa-solid fa-cart-shopping" style="color: #f9b125;"></i></a>
        <?php endif; ?>
        
        <a href="/perfil.php"><i class="fa-solid fa-user" style="color: #f9b125;"></i></a>
    </nav>
</header>
